<?php
include("confi/FD_Config.php");
header("Location: ".DEFAULT_CONTROLLER."/");

?>