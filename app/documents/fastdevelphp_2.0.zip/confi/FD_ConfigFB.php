<?php
define("APP_ID_FB","398506063531508");
define("APP_SECRET_FB","5fe734ec43a70ccdd88a6722f639aadd");
define("SYSTEM_ID","1");
define("FANPAGE_ID_FB","");
define("PERMISSIONS_FB","publish_stream,email");
?>