<h2>Bienvenidos a "FASTDEVELPHP".</h2><br /><br />
Pasos para empezar con su proyecto:
<br />- crear controladores
<br />- crear vistas
<br />Mas informacion en <a target="_blank" href="http://www.fastdevelphp.sysdecom.com">www.fastdevelphp.sysdecom.com</a>
<br /><br />
Tambien puedes usar nuestro <a target="_blank" href="<?php echo ROOT_PATH ?>fastdevelphp/ui_scaffold">Scaffold module</a> para generar controladores y vistas - CRUD