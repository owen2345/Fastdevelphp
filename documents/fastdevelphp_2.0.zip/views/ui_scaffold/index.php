<h3>Bienvenido al modulo de scaffold de Fastdevelphp.</h3>
<br />
<strong>Objetivo:</strong>
<ul>
    <li>- auto generar los controladores</li>
    <li>- auto generar las vistas</li>
    <li>- funcionalidades de Crear, Editar, Eliminar, Listar</li>
</ul>
<br />
<br />

<strong>Ventajas:</strong>
<ul>
    <li>- ahorra tiempo</li>
    <li>- codigo ordenado</li>
</ul>
<br />
<br />

<a href="<?php echo ROOT_PATH ?>ui_scaffold/create" title="Genrear nuevo">Generar nuevo</a>